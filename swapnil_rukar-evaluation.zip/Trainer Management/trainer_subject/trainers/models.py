from django.db import models

class Subject(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Trainer(models.Model):
    empId = models.CharField(max_length=100) 
    name = models.CharField(max_length=100)
    email = models.EmailField(default='test@example.com')
    phone = models.CharField(max_length=15, default='0000000000')
    subjects = models.ManyToManyField(Subject)

    def __str__(self):
        return self.name
