from django.shortcuts import render, redirect, get_object_or_404
from .models import Trainer, Subject
from .forms import TrainerForm, SubjectForm

from django.shortcuts import render

def home(request):
    return render(request, 'trainers/homepage.html')

def trainer_list(request):
    trainers = Trainer.objects.all()
    return render(request, 'trainers/trainer_list.html', {'trainers': trainers})

def trainer_create(request):
    if request.method == 'POST':
        form = TrainerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('trainer_create')
    else:
        form = TrainerForm()
    return render(request, 'trainers/trainer_form.html', {'form': form})

def subject_create(request):
    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('subject_list')
    else:
        form = SubjectForm()
    return render(request, 'trainers/subject_form.html', {'form': form})

def trainer_detail(request, id):
    trainer = get_object_or_404(Trainer, id=id)
    return render(request, 'trainers/trainer_detail.html', {'trainer': trainer})

def trainer_delete(request, id): 
    trainer = get_object_or_404(Trainer, id=id)
    if request.method == 'POST':
        trainer.delete()
        return redirect('trainer_list')
    return render(request, 'trainers/trainer_delete.html', {'trainer': trainer})

def trainers_by_subject(request, subject_name):
    trainers = Trainer.objects.filter(subjects__name=subject_name)
    return render(request, 'trainers/trainer_by_subject.html', {'trainers': trainers, 'subject_name': subject_name})

def subject_list(request):
    subjects = Subject.objects.all()
    return render(request, 'trainers/subject_list.html', {'subjects': subjects})

def subject_detail(request, id):
    subject = get_object_or_404(Subject, id=id)
    trainers = subject.trainer_set.all()
    return render(request, 'trainers/subject_detail.html', {'subject': subject, 'trainers': trainers})