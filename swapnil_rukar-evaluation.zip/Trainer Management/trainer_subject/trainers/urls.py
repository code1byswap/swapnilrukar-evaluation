
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Home view
    path('trainer/', views.trainer_list, name='trainer_list'),
    path('trainer/add/', views.trainer_create, name='trainer_create'),
    path('subject/add/', views.subject_create, name='subject_create'),
    path('trainer/<int:id>/', views.trainer_detail, name='trainer_detail'),
    path('trainer/<str:subject_name>/topic/', views.trainers_by_subject, name='trainers_by_subject'),
    path('trainer/<int:id>/delete/', views.trainer_delete, name='trainer_delete'),
    path('subjects/', views.subject_list, name='subject_list'),
    path('subject/<int:id>/', views.subject_detail, name='subject_detail'),
]
