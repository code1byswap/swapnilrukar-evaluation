from django.contrib import admin
from .models import Trainer, Subject

admin.site.register(Trainer)
admin.site.register(Subject)
